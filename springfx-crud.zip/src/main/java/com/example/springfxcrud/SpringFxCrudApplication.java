package com.example.springfxcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFxCrudApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpringFxCrudApplication.class, args);
    }
}
