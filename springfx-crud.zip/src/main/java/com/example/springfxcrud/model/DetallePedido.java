package com.example.springfxcrud.model;

import jakarta.persistence.*;

@Entity
public class DetallePedido {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    private Pedido pedido;
    @ManyToOne
    private Producto producto;
    private Integer cantidad;
    private Double precioUnitario;
    private Double subtotal;
    private String notas;
    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public Pedido getPedido(){return pedido;} public void setPedido(Pedido pedido){this.pedido=pedido;}
    public Producto getProducto(){return producto;} public void setProducto(Producto producto){this.producto=producto;}
    public Integer getCantidad(){return cantidad;} public void setCantidad(Integer cantidad){this.cantidad=cantidad;}
    public Double getPrecioUnitario(){return precioUnitario;} public void setPrecioUnitario(Double precioUnitario){this.precioUnitario=precioUnitario;}
    public Double getSubtotal(){return subtotal;} public void setSubtotal(Double subtotal){this.subtotal=subtotal;}
    public String getNotas(){return notas;} public void setNotas(String notas){this.notas=notas;}
}
